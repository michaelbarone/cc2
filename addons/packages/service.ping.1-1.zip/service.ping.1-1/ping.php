<?php
	echo "Starting script:<br /><br />";

	function Curl($content){
		
		$headers = [
			'X-Apple-Tz: 0',
			'X-Apple-Store-Front: 143444,12',
			'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Accept-Encoding: gzip, deflate',
			'Accept-Language: en-US,en;q=0.5',
			'Cache-Control: no-cache',
			'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
			'Host: www.example.com',
			'Referer: http://www.example.com/index.php', //Your referrer address
			'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0',
			'X-MicrosoftAjax: Delta=true'
		];

		
		
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, "$content");
		curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
		//curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$output = curl_exec($ch);
		return $output;
	}



	$therequest = urlencode('\\"id\\":2,\\"method\\":\\"setPowerStatus\\",\\"version\\":\\"1.0\\",\\"params\\":[{ \\"status\\" : false}]');
	$jsoncontents = "192.168.3.227:2870?{".$therequest."}";
	$thisoutput = Curl($jsoncontents);

	print_r($thisoutput);


exit;

if(!isset($thisip)){ $thisip = "192.168.3.221"; }
if(strpos($thisip, "/") != false) {
	$thisip = substr($thisip, 0, strpos($thisip, "/"));
}
if (strncasecmp(PHP_OS, 'WIN', 3) == 0) {
	$pingresult = exec("ping -n 2 -w 2 $thisip", $output, $status);
	// echo 'This is a server using Windows!';
} else {
	$pingresult = exec("/bin/ping -c2 -w2 $thisip", $output, $status);
	// echo 'This is a server not using Windows!';
}

echo "$status";
echo "<br>";
print_r($output);

echo $output[6];
echo "<br>";echo "<br>";












		$newping = array();
		$sent = 0;
		$lost = 0;
		$timeMax = 0;
		$timeAve = 0;
		if (strncasecmp(PHP_OS, 'WIN', 3) == 0) {
			if(isset($output[6])){
				$exoutput = explode(',',$output[6]);
				$sent = preg_replace('/\D/', '', $exoutput[0]);
				$lost = $sent - preg_replace('/\D/', '', $exoutput[1]);
			}
			if(isset($output[8])){
				$exoutput = explode(',',$output[8]);
				$timeMax = preg_replace('/\D/', '', $exoutput[1]);
				$timeAve = preg_replace('/\D/', '', $exoutput[2]);
			}
		} else {
			echo "linux";
			if(isset($output[5])){
				$exoutput = explode(',',$output[5]);
				$sent = preg_replace('/\D/', '', $exoutput[0]);
				$lost = $sent - preg_replace('/\D/', '', $exoutput[1]);
			}elseif(isset($output[3])){
				$exoutput = explode(',',$output[3]);
				$sent = preg_replace('/\D/', '', $exoutput[0]);
				$lost = $sent - preg_replace('/\D/', '', $exoutput[1]);
			}		
			if(isset($output[6])){
				$exoutput = explode('=',$output[6]);
				$exoutput = explode('/',$exoutput[1]);
				$timeMax = round($exoutput[2]);
				$timeAve = round($exoutput[1]);
			}			
		}
		$newping['sent']=$sent;
		$newping['lost']=$lost;
		$newping['timeMax']=$timeMax;
		$newping['timeAve']=$timeAve;
		$lastUpdate = time();
		$newping['lastUpdate']=$lastUpdate;
		

print_r($newping);
echo "<br>";echo "<br>";
$json = json_encode($newping);


print_r($json);





echo "<br>";
$json = json_encode($output);


print_r($json);

echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";


$result = preg_replace('/\"",.*?\,"",/', '', $json);

print_r($result);
print_r("thisone^^");
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
$result = json_encode($result);
print_r($result);

echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";


if ($status == "0") {
	//$status = "alive";
	return "alive";	
} else {
	//$status = "dead";
	return "dead";
}





?>